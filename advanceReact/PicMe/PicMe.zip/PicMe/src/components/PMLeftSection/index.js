export { defaults } from "./PMLeftSection";
