export { defaults } from "./CardDetailScreen";
