export const LOGIN_URL = "auth/sign_in";
export const SIGNUP_URL = "auth";
export const FORGOT_URL = "/auth/password";
export const ME = "users/me";
export const SEARCH_PHOTOGRAPHER_URL = "/customers/search_photographer";
