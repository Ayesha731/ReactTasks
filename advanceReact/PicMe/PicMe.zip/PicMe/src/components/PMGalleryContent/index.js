export { defaults } from "./PMGalleryContent";
