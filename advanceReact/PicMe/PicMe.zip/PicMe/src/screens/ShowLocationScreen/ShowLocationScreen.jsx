import React, { useState } from "react";
import PMNavbar from "../../components/PMNavbar/PMNavbar";
import PMMainHeroSection from "../../components/PMMainHeroSection/PMMainHeroSection";
import PMMapSearchBar from "../../components/PMMapSearchBar/PMMapSearchBar";
import PMSidebar from "../../components/PMSidebar/PMSidebar";
import map from "../../assets/images/map.png";

const ShowLocationScreen = () => {
  const [currentView, setCurrentView] = useState("map"); // "map" or "list"
  const [searchData, setSearchData] = useState({
    photographerName: "",
    fromDate: null,
    toDate: null,
    latitude: null,
    longitude: null,
    searchType: "name", // "name", "location", "category"
  });

  // Handle search from PMMapSearchBar
  const handleSearch = (searchParams) => {
    console.log("Search params received:", searchParams);

    // Determine search type based on input
    let searchType = "name";
    if (searchParams.latitude && searchParams.longitude) {
      searchType = "location";
    } else if (
      searchParams.photographerName &&
      ["wedding", "birthday", "concert", "travel", "street"].some((cat) =>
        searchParams.photographerName.toLowerCase().includes(cat)
      )
    ) {
      searchType = "category";
    }

    setSearchData({
      ...searchParams,
      searchType,
    });
    setCurrentView("list");
  };

  // Handle back button to return to map search
  const handleBackToSearch = () => {
    setCurrentView("map");
  };

  // Handle location selection (for future use with location picker)
  const handleLocationSelect = (lat, lng, address) => {
    setSearchData((prev) => ({
      ...prev,
      latitude: lat,
      longitude: lng,
      location: address,
      searchType: "location",
    }));
    setCurrentView("list");
  };

  return (
    <div>
      <PMNavbar />
      <PMMainHeroSection>
        <div
          className="map-container"
          style={{
            backgroundImage: `url(${map})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            width: "100%",
            height: "100%",
            position: "relative",
          }}
        >
          {/* Conditionally render components based on current view */}
          {currentView === "map" ? (
            <PMMapSearchBar
              onSearch={handleSearch}
              onLocationSelect={handleLocationSelect}
            />
          ) : (
            <PMSidebar searchData={searchData} onBack={handleBackToSearch} />
          )}
        </div>
      </PMMainHeroSection>
    </div>
  );
};

export default ShowLocationScreen;
