import logo from "../assets/images/logo.png";
import cameraBlueFullImg from "../assets/images/cameraFullBlue.png";
import cameraBlueHalfImg from "../assets/images/cameraBlueHalf.png";
import notFound from "../assets/images/notFound.png";
import logo2 from "../assets/images/logo2.png";
const Images = {
  logo,
  cameraBlueFullImg,
  cameraBlueHalfImg,
  notFound,
  logo2,
};

export default Images;
