export { defaults } from "./PMLoadingSpinner";
