export { defaults } from "./PMTabs";
