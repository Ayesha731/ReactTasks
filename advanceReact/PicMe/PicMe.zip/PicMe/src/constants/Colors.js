export const Colors = {
  primaryColor: "#2BAFC7",
  secondaryColor: " #ffffff",
  gray100: " #E4DFDF",
  gray200: "#747688",
  gray300: "#807A7A",
  yellow: "#FBBE47",
  red: "#E53535",
  basicCardColor: "#2bc7a5cc",
  essentailCardColor: "#2bafc7",
  premiumCardColor: "#1aceef",
};
