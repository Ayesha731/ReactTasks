import React from "react";
import "./PMCustomerCardStyle.css";
const PMCustomerCard = ({ children }) => {
  return <div className="card-container">{children}</div>;
};

export default PMCustomerCard;
