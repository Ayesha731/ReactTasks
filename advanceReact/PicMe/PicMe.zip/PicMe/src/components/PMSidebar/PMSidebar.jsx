import React, { useEffect, useState, useCallback } from "react";

import { FaSearch, FaStar } from "react-icons/fa";

const photographerTypes = [
  "Wedding Photographer",
  "Street Photographer",
  "Birthday Photographer",
  "Concert Photographer",
  "Travel Photographer",
];

const PhotographersList = () => {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [selectedType, setSelectedType] = useState("Street Photographer");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [photographers, setPhotographers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // ✅ Debounce Search (runs 500ms after user stops typing)
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 500);
    return () => clearTimeout(timer);
  }, [search]);

  // ✅ Fetch photographers
  const fetchPhotographers = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(
        `http://your-backend-api.com/photographers?search=${debouncedSearch}&type=${selectedType}`
      );
      if (!response.ok) throw new Error("Failed to fetch photographers");
      const data = await response.json();
      setPhotographers(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, selectedType]);

  // ✅ Call API whenever search/type changes
  useEffect(() => {
    fetchPhotographers();
  }, [fetchPhotographers]);

  // ✅ Handle outside click to close dropdown
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest(".dropdown-wrapper")) setDropdownOpen(false);
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  return (
    <div className="photographers-container">
      <h2>Photographers Lists</h2>
      <p>Find the best photographers in your area for your next event!</p>

      {/* Search Input */}
      <PMInput
        icon={<FaSearch />}
        placeholder="Search photographers"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* Dropdown */}
      <div className="dropdown-wrapper">
        <PMButton
          varient="primary"
          onClick={() => setDropdownOpen(!dropdownOpen)}
        >
          {selectedType}
        </PMButton>
        {dropdownOpen && (
          <ul className="dropdown-list">
            {photographerTypes.map((type) => (
              <li
                key={type}
                className={selectedType === type ? "active" : ""}
                onClick={() => {
                  setSelectedType(type);
                  setDropdownOpen(false);
                }}
              >
                {type}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Loading & Error */}
      {loading && <p>Loading photographers...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Photographer Cards */}
      <div className="photographers-grid">
        {!loading && photographers.length > 0
          ? photographers.map((p, index) => (
              <div className="card" key={index}>
                <img
                  src={
                    p.avatar ||
                    "https://cdn-icons-png.flaticon.com/512/5556/5556499.png"
                  }
                  alt={p.name}
                  className="avatar"
                />
                <h3>{p.name}</h3>
                <p>{p.type}</p>
                <div className="rating">
                  <FaStar color="gold" />{" "}
                  <span>
                    {p.rating} ({p.reviews} reviews)
                  </span>
                </div>
              </div>
            ))
          : !loading && <p>No photographers found</p>}
      </div>
    </div>
  );
};

export default PhotographersList;
